-- Together Chat database schema. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Friend',
  username text unique,
  friend_code text unique,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','blocked')),
  created_at timestamptz not null default now(),
  constraint friendship_not_self check (user_a <> user_b),
  constraint friendship_pair_unique unique (user_a,user_b)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  message_type text not null default 'text' check (message_type in ('text','image','file','voice')),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  constraint message_not_self check (sender_id <> receiver_id)
);
create index if not exists messages_pair_created_idx on public.messages(sender_id,receiver_id,created_at);
create index if not exists friendships_user_a_idx on public.friendships(user_a,status);
create index if not exists friendships_user_b_idx on public.friendships(user_b,status);

alter table public.profiles enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Profiles visible to signed-in users" on public.profiles;
create policy "Profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "Users create their own profile" on public.profiles;
create policy "Users create their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update their own profile" on public.profiles;
create policy "Users update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Participants can view friendships" on public.friendships;
create policy "Participants can view friendships" on public.friendships for select to authenticated using (auth.uid() = user_a or auth.uid() = user_b);
drop policy if exists "Users can send friend requests" on public.friendships;
create policy "Users can send friend requests" on public.friendships for insert to authenticated with check (auth.uid() = user_a and status = 'pending');
drop policy if exists "Recipient can respond to requests" on public.friendships;
create policy "Recipient can respond to requests" on public.friendships for update to authenticated using (auth.uid() = user_b) with check (auth.uid() = user_b and status in ('accepted','blocked'));

drop policy if exists "Chat participants can read messages" on public.messages;
create policy "Chat participants can read messages" on public.messages for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "Sender can send messages to accepted friends" on public.messages;
create policy "Sender can send messages to accepted friends" on public.messages for insert to authenticated with check (
 auth.uid() = sender_id and exists (
   select 1 from public.friendships f where f.status='accepted' and
   ((f.user_a=sender_id and f.user_b=receiver_id) or (f.user_b=sender_id and f.user_a=receiver_id))
 )
);
drop policy if exists "Receiver can mark messages read" on public.messages;
create policy "Receiver can mark messages read" on public.messages for update to authenticated using (auth.uid() = receiver_id) with check (auth.uid() = receiver_id);

-- Enable realtime for new message delivery (ignore duplicate publication errors if already added).
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

-- Optional public media bucket for image/file sharing. For private media, use signed URLs instead.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-media','chat-media',true,12582912,array['image/*','video/*','application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
on conflict (id) do nothing;
drop policy if exists "Authenticated users upload chat media" on storage.objects;
create policy "Authenticated users upload chat media" on storage.objects for insert to authenticated with check (bucket_id='chat-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Chat media public read" on storage.objects;
create policy "Chat media public read" on storage.objects for select to public using (bucket_id='chat-media');
